import letras_random from "./game.js";

function Letras() {
  return (
    <>
      <div id="letra">{letras_random[1]}</div>
      <div id="letra">{letras_random[2]}</div>
      <div id="letra">{letras_random[3]}</div>
      <div id="letra">{letras_random[4]}</div>
      <div id="letra">{letras_random[5]}</div>
      <div id="letra">{letras_random[6]}</div>
      <div id="letra">{letras_random[7]}</div>
      <div id="letra">{letras_random[8]}</div>
      <div id="letra">{letras_random[9]}</div>
      <div id="letra">{letras_random[10]}</div>
      <div id="letra">{letras_random[11]}</div>
      <div id="letra">{letras_random[12]}</div>
      <div id="letra">{letras_random[13]}</div>
      <div id="letra">{letras_random[14]}</div>
      <div id="letra">{letras_random[15]}</div>
      <div id="letra">{letras_random[16]}</div>
    </>
  );
}

export default Letras;
